﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.PlayerLoop;
using UnityEngine.XR.ARFoundation;

public class ARPlaceObject : MonoBehaviour
{
    // Reference to object prefab
    [SerializeField]
    private List<GameObject> arPrefab; // creates a list of prefabs



    // Reference to an instance of the object that will be moved.
    private List<GameObject> arInstance = new List<GameObject>(); // create a list of instances



    // Reference to Raycast Manager used to make raycasts to detect surfaces.
    private ARRaycastManager arRaycaster;

    // Flag if an object was placed or it should be moved
    private bool objectPlaced = false;

    private int listPos = 0;

    /// <summary>
    /// Unity method called in before first frame.
    /// </summary>
    void Start()
    {
        // Get reference to AR Raycast Manager within this game object
        arRaycaster = GetComponent<ARRaycastManager>();
        // Debug.Log("Count of prefabs: " + arPrefab.Count);
        // Create instance of our object and hide it until it won't be placed

        for (int i = 0; i < arPrefab.Count; i++)
        {
            arInstance.Add(Instantiate(arPrefab[i])); // add to the instance list
            arInstance[i].gameObject.SetActive(false);
        }

        // Debug.Log("Instance: " + arInstance.Count);

        // 

    }

    /// <summary>
    /// Unity method called every frame.
    /// </summary>
    void Update()
    {
        // If instance is placed then skip update.
        if (objectPlaced)
            return;

        // Make a list of AR hits
        List<ARRaycastHit> hits = new List<ARRaycastHit>();

        // Center point of screen with 4 units of depth what will be used to make raycast
        var screenPoint = new Vector3(Screen.width / 2.0f, Screen.height / 2.0f, 4);

        // Trying to find a sufrace in world.
        if (arRaycaster.Raycast(screenPoint, hits))
        {
            // If we did hit something then we should place the instance in that point in space.

            // Order hits to find closest one.
            hits.OrderBy(h => h.distance);
            var pose = hits[0].pose;

            // Activate instance and move it to position on detected surface
            if (Input.touchCount > 0 && listPos < arInstance.Count)
            {
                arInstance[listPos].gameObject.SetActive(true);

                arInstance[listPos].transform.position = new Vector3(pose.position.x + i, pose.position.y); ;
                arInstance[listPos].transform.up = pose.up;
                listPos++;
            }
            /*for (int i = 0; i < arInstance.Count; i++)
            {
                arInstance[i].gameObject.SetActive(true);
                
                arInstance[i].transform.position = new Vector3(pose.position.x + i, pose.position.y); ;
                arInstance[i].transform.up = pose.up;
            }*/

        }
        else
        {
            // If we didn't hit anything than we should hide instance
            //arInstance.gameObject.SetActive(false);
        }
    }

    /// <summary>
    /// Method used to disable object movement, called by Place Button.
    /// </summary>
    public void PlacingFinished()
    {
        objectPlaced = true;
    }

    /// <summary>
    /// Method used to enable object movement, called by Move Button.
    /// </summary>
    public void PlacingBegin()
    {
        objectPlaced = false;
    }
}
